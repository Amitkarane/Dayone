# dayone
Learnings about github and licenses
 
## Github Introduction
>acessing many codes 

>creating our Repository

>Acess various Branching

>Merging Branches

## License
>1.Apache License 2.0

# Images Of Profile
![Screenshot (2)](https://user-images.githubusercontent.com/116140440/196608526-c9f59871-1129-4f80-93bd-1fab1270f770.png)
![Screenshot (3)](https://user-images.githubusercontent.com/116140440/196608555-6c9aab6b-fb14-4b09-ace0-363cafda7885.png)

## Thank you
